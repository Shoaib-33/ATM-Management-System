#include <iostream>
using namespace std;

#include "scheduler.h"
#include "server.h"
#include "serviceFacility.h"

int main ()
{
    Scheduler *ATM = new Scheduler ();
    ATM->initialize ();

    ATM_Facilites* atm_Facilites = new ATM_Facilites (20.0,10.0,10.0);

    ATM->run ();

    atm_Facilites->generateReport();

    return 0;
}
