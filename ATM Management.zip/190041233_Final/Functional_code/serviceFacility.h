#ifndef MSQS_2_SERVERS_SCENARIO_1_SERVICEFACILITY_H
#define MSQS_2_SERVERS_SCENARIO_1_SERVICEFACILITY_H
#include "server.h"

class ATM_Facilites {
private:
    Server* s1;
    Server* s2;
public:
    ATM_Facilites(double arrivalMean, double departMean1, double departMean2);
    void generateReport();
};


#endif //MSQS_2_SERVERS_SCENARIO_1_SERVICEFACILITY_H
